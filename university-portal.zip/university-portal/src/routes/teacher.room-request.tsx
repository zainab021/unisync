import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { DoorOpen, BellRing } from "lucide-react";
import { rooms, roomTimeSlots, roomRequestHistory } from "@/data/data";
import StatusBadge from "@/components/StatusBadge";
import { toast } from "sonner";

export const Route = createFileRoute("/teacher/room-request")({
  head: () => ({ meta: [{ title: "Room Request — Teacher Portal" }] }),
  component: RoomRequestPage,
});

type Request = {
  id: string;
  room: string;
  date: string;
  slot: string;
  reason: string;
  status: "Pending" | "Approved" | "Rejected";
};

function RoomRequestPage() {
  const [room, setRoom] = useState(rooms[0].id);
  const [date, setDate] = useState("");
  const [slot, setSlot] = useState(roomTimeSlots[0]);
  const [reason, setReason] = useState("");
  const [history, setHistory] = useState<Request[]>(roomRequestHistory);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date || !reason.trim()) return toast.error("Please fill in all fields");
    const id = `RR-${new Date().getFullYear()}-${String(history.length + 12).padStart(3, "0")}`;
    setHistory([{ id, room, date, slot, reason, status: "Pending" }, ...history]);
    toast.success("Room request submitted", {
      icon: <BellRing className="h-4 w-4" />,
      description: "Notification sent to admin · awaiting approval",
    });
    setDate(""); setReason("");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white flex items-center gap-2">
          <DoorOpen className="h-6 w-6 text-amber-400" /> Room Request
        </h1>
        <p className="mt-1 text-sm text-slate-400">Reserve a room for extra classes, talks, or meetings.</p>
      </div>

      <form onSubmit={submit} className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-xl space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Room</label>
            <select
              value={room}
              onChange={(e) => setRoom(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40"
            >
              {rooms.map((r) => <option key={r.id} value={r.id} className="bg-slate-900">{r.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40 [color-scheme:dark]"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Time Slot</label>
            <div className="mt-1.5 flex flex-wrap gap-2">
              {roomTimeSlots.map((s) => (
                <button
                  type="button"
                  key={s}
                  onClick={() => setSlot(s)}
                  className={`rounded-lg border px-3 py-2 text-xs font-semibold transition tabular-nums ${
                    slot === s
                      ? "border-amber-500/50 bg-amber-500/15 text-amber-300"
                      : "border-white/10 bg-white/5 text-slate-400 hover:text-white"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Reason</label>
          <textarea
            rows={3}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Why do you need this room?"
            className="mt-1.5 w-full resize-none rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40 placeholder:text-slate-600"
          />
        </div>

        <button
          type="submit"
          className="rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 px-5 py-2.5 text-sm font-bold text-slate-900 hover:from-amber-300 hover:to-amber-400 shadow-lg shadow-amber-500/20"
        >
          Submit Request
        </button>
      </form>

      <div className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
        <div className="border-b border-white/5 px-6 py-4">
          <h2 className="font-semibold text-white">Request History</h2>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-white/[0.02] text-left text-xs uppercase tracking-wider text-slate-400">
            <tr>
              <th className="px-6 py-3">ID</th>
              <th className="px-6 py-3">Room</th>
              <th className="px-6 py-3">Date</th>
              <th className="px-6 py-3">Time</th>
              <th className="px-6 py-3">Reason</th>
              <th className="px-6 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {history.map((r) => (
              <tr key={r.id} className="hover:bg-white/[0.02]">
                <td className="px-6 py-3 font-mono text-xs text-slate-400">{r.id}</td>
                <td className="px-6 py-3 text-white">{r.room}</td>
                <td className="px-6 py-3 text-slate-300 tabular-nums">{r.date}</td>
                <td className="px-6 py-3 text-slate-400 tabular-nums">{r.slot}</td>
                <td className="px-6 py-3 text-slate-400 max-w-xs truncate">{r.reason}</td>
                <td className="px-6 py-3">
                  <StatusBadge
                    label={r.status}
                    tone={r.status === "Approved" ? "success" : r.status === "Rejected" ? "danger" : "warning"}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
