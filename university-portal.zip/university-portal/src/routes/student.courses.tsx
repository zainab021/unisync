import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { BookOpen, User, Award, Search } from "lucide-react";
import { courses } from "@/data/data";
import Modal from "@/components/Modal";

export const Route = createFileRoute("/student/courses")({
  head: () => ({ meta: [{ title: "Courses — Student Portal" }] }),
  component: CoursesPage,
});

function CoursesPage() {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<typeof courses[number] | null>(null);

  const filtered = courses.filter(
    (c) => c.name.toLowerCase().includes(query.toLowerCase()) || c.teacher.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">My Courses</h1>
          <p className="mt-1 text-sm text-slate-400">Spring 2026 · {courses.length} enrolled</p>
        </div>
        <div className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 w-72">
          <Search className="h-4 w-4 text-slate-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search courses or teachers"
            className="w-full bg-transparent py-2.5 text-sm text-white outline-none placeholder:text-slate-500"
          />
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {filtered.map((c) => (
          <button
            key={c.id}
            onClick={() => setSelected(c)}
            className="text-left rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur-xl hover:border-amber-500/40 hover:bg-white/[0.05] transition group"
          >
            <div className="flex items-start justify-between">
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-amber-500/15 text-amber-400">
                <BookOpen className="h-5 w-5" />
              </div>
              <span className="rounded-md bg-white/5 px-2 py-1 text-[11px] font-semibold text-slate-400">
                {c.credits} CR
              </span>
            </div>
            <p className="mt-4 text-xs text-slate-500">{c.id}</p>
            <h3 className="text-base font-semibold text-white group-hover:text-amber-300 transition">{c.name}</h3>
            <p className="mt-1 flex items-center gap-1.5 text-xs text-slate-400">
              <User className="h-3 w-3" /> {c.teacher}
            </p>
            <div className="mt-5">
              <div className="mb-1.5 flex justify-between text-xs">
                <span className="text-slate-500">Progress</span>
                <span className="font-semibold text-amber-400 tabular-nums">{c.progress}%</span>
              </div>
              <div className="h-2 rounded-full bg-white/5">
                <div className="h-full rounded-full bg-gradient-to-r from-amber-400 to-amber-500" style={{ width: `${c.progress}%` }} />
              </div>
            </div>
          </button>
        ))}
        {filtered.length === 0 && (
          <p className="col-span-full text-center text-sm text-slate-500 py-12">No courses match your search.</p>
        )}
      </div>

      <Modal open={!!selected} onClose={() => setSelected(null)} title={selected?.name}>
        {selected && (
          <div className="space-y-3 text-sm">
            <div className="flex items-center gap-2"><Award className="h-4 w-4 text-amber-400" /> {selected.id} · {selected.credits} Credit Hours</div>
            <div className="flex items-center gap-2"><User className="h-4 w-4 text-amber-400" /> {selected.teacher}</div>
            <div>
              <p className="text-xs uppercase tracking-wider text-slate-500 mb-1">Course Progress</p>
              <div className="h-2 rounded-full bg-white/5">
                <div className="h-full rounded-full bg-amber-500" style={{ width: `${selected.progress}%` }} />
              </div>
              <p className="mt-1 text-xs text-slate-400">{selected.progress}% completed</p>
            </div>
            <p className="text-slate-400">
              This course covers fundamental and advanced concepts with weekly assignments,
              quizzes, and a final project. Refer to the LMS for the full syllabus.
            </p>
          </div>
        )}
      </Modal>
    </div>
  );
}
