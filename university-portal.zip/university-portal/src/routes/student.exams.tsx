import { createFileRoute } from "@tanstack/react-router";
import { Calendar, Clock, MapPin, FileText } from "lucide-react";
import { exams } from "@/data/data";

export const Route = createFileRoute("/student/exams")({
  head: () => ({ meta: [{ title: "Exams — Student Portal" }] }),
  component: ExamsPage,
});

function ExamsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">Exam Schedule</h1>
        <p className="mt-1 text-sm text-slate-400">{exams.length} upcoming · Mid-Terms Spring 2026</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {exams.map((e) => {
          const d = new Date(e.date);
          return (
            <div
              key={e.id}
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur-xl hover:border-amber-500/40 transition"
            >
              <div className="absolute -top-12 -right-8 h-32 w-32 rounded-full bg-amber-500/10 blur-2xl group-hover:bg-amber-500/20 transition" />
              <div className="relative flex items-start gap-4">
                <div className="grid h-16 w-16 shrink-0 place-items-center rounded-xl border border-amber-500/30 bg-amber-500/10">
                  <p className="text-[10px] font-semibold uppercase text-amber-400">
                    {d.toLocaleString("en", { month: "short" })}
                  </p>
                  <p className="text-xl font-bold text-white leading-none">{d.getDate()}</p>
                </div>
                <div className="min-w-0 flex-1">
                  <span className="rounded-md bg-white/5 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    {e.type}
                  </span>
                  <p className="mt-1.5 font-semibold text-white truncate">{e.subject}</p>
                  <div className="mt-3 space-y-1.5 text-xs text-slate-400">
                    <p className="flex items-center gap-1.5"><Clock className="h-3 w-3" /> {e.time} · {e.duration}</p>
                    <p className="flex items-center gap-1.5"><MapPin className="h-3 w-3" /> {e.venue}</p>
                    <p className="flex items-center gap-1.5"><Calendar className="h-3 w-3" /> {e.date}</p>
                  </div>
                </div>
              </div>
              <button className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-md border border-white/5 bg-white/5 py-2 text-xs font-medium text-slate-300 hover:bg-amber-500/15 hover:text-amber-300 transition">
                <FileText className="h-3 w-3" /> View Admit Card
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
