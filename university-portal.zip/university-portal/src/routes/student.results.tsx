import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Calculator, Plus, Trash2 } from "lucide-react";
import { semesters } from "@/data/data";
import { toast } from "sonner";

export const Route = createFileRoute("/student/results")({
  head: () => ({ meta: [{ title: "Results — Student Portal" }] }),
  component: ResultsPage,
});

const GRADE_POINTS: Record<string, number> = {
  "A+": 4.0, A: 4.0, "A-": 3.7, "B+": 3.3, B: 3.0, "B-": 2.7, "C+": 2.3, C: 2.0, D: 1.0, F: 0.0,
};

function ResultsPage() {
  const [active, setActive] = useState(0);
  const [calcRows, setCalcRows] = useState([
    { course: "Course 1", credits: 3, grade: "A" },
    { course: "Course 2", credits: 3, grade: "B+" },
  ]);

  const sem = semesters[active];

  const calcGpa = useMemo(() => {
    const totalCr = calcRows.reduce((a, r) => a + r.credits, 0);
    if (!totalCr) return 0;
    const points = calcRows.reduce((a, r) => a + r.credits * (GRADE_POINTS[r.grade] ?? 0), 0);
    return points / totalCr;
  }, [calcRows]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">Academic Results</h1>
        <p className="mt-1 text-sm text-slate-400">View your semester transcripts and forecast your GPA.</p>
      </div>

      {/* Semester tabs */}
      <div className="flex flex-wrap gap-2">
        {semesters.map((s, i) => (
          <button
            key={s.name}
            onClick={() => setActive(i)}
            className={`rounded-lg border px-4 py-2 text-sm font-medium transition ${
              active === i
                ? "border-amber-500/40 bg-amber-500/15 text-amber-300"
                : "border-white/10 bg-white/5 text-slate-400 hover:text-white"
            }`}
          >
            {s.name} <span className="ml-1.5 text-xs opacity-70">· {s.gpa.toFixed(2)}</span>
          </button>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Grade table */}
        <div className="lg:col-span-2 overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
            <h2 className="font-semibold text-white">{sem.name}</h2>
            <span className="rounded-md bg-amber-500/15 px-2.5 py-1 text-xs font-bold text-amber-300">
              GPA {sem.gpa.toFixed(2)}
            </span>
          </div>
          <table className="w-full text-sm">
            <thead className="text-left text-xs uppercase tracking-wider text-slate-400">
              <tr>
                <th className="px-6 py-3">Course</th>
                <th className="px-6 py-3">Credits</th>
                <th className="px-6 py-3">Grade</th>
                <th className="px-6 py-3">Points</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {sem.grades.map((g) => (
                <tr key={g.course} className="hover:bg-white/[0.02]">
                  <td className="px-6 py-3 font-medium text-white">{g.course}</td>
                  <td className="px-6 py-3 text-slate-300 tabular-nums">{g.credits}</td>
                  <td className="px-6 py-3">
                    <span className="rounded-md bg-emerald-500/15 px-2 py-0.5 text-xs font-bold text-emerald-300">
                      {g.grade}
                    </span>
                  </td>
                  <td className="px-6 py-3 text-amber-400 tabular-nums">{g.points.toFixed(1)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* GPA Calculator */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-xl">
          <div className="flex items-center gap-2">
            <Calculator className="h-4 w-4 text-amber-400" />
            <h3 className="font-semibold text-white">GPA Calculator</h3>
          </div>
          <p className="mt-1 text-xs text-slate-500">Estimate your GPA before finals.</p>

          <div className="mt-4 space-y-2">
            {calcRows.map((row, i) => (
              <div key={i} className="flex gap-2">
                <input
                  value={row.course}
                  onChange={(e) => {
                    const c = [...calcRows];
                    c[i] = { ...c[i], course: e.target.value };
                    setCalcRows(c);
                  }}
                  className="flex-1 rounded-md border border-white/10 bg-white/5 px-2 py-1.5 text-xs text-white outline-none focus:border-amber-500/40"
                />
                <input
                  type="number"
                  min={1}
                  max={6}
                  value={row.credits}
                  onChange={(e) => {
                    const c = [...calcRows];
                    c[i] = { ...c[i], credits: Number(e.target.value) || 0 };
                    setCalcRows(c);
                  }}
                  className="w-14 rounded-md border border-white/10 bg-white/5 px-2 py-1.5 text-xs text-white outline-none focus:border-amber-500/40"
                />
                <select
                  value={row.grade}
                  onChange={(e) => {
                    const c = [...calcRows];
                    c[i] = { ...c[i], grade: e.target.value };
                    setCalcRows(c);
                  }}
                  className="w-16 rounded-md border border-white/10 bg-white/5 px-2 py-1.5 text-xs text-white outline-none focus:border-amber-500/40"
                >
                  {Object.keys(GRADE_POINTS).map((g) => (
                    <option key={g} value={g} className="bg-slate-900">{g}</option>
                  ))}
                </select>
                <button
                  onClick={() => setCalcRows(calcRows.filter((_, idx) => idx !== i))}
                  className="grid place-items-center rounded-md border border-white/10 bg-white/5 px-2 text-rose-400 hover:bg-rose-500/15"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>

          <button
            onClick={() => setCalcRows([...calcRows, { course: `Course ${calcRows.length + 1}`, credits: 3, grade: "A" }])}
            className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-white/10 py-2 text-xs text-slate-400 hover:border-amber-500/40 hover:text-amber-300"
          >
            <Plus className="h-3 w-3" /> Add course
          </button>

          <div className="mt-5 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-center">
            <p className="text-xs uppercase tracking-wider text-amber-300/80">Projected GPA</p>
            <p className="mt-1 text-4xl font-bold text-amber-300 tabular-nums">{calcGpa.toFixed(2)}</p>
          </div>

          <button
            onClick={() => toast.success("GPA estimate saved")}
            className="mt-4 w-full rounded-md bg-amber-500 py-2 text-sm font-bold text-slate-900 hover:bg-amber-400"
          >
            Save Estimate
          </button>
        </div>
      </div>
    </div>
  );
}
