import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Send, Lock } from "lucide-react";
import { teacherCourseOptions, teacherStudents, gradebookSeed } from "@/data/data";
import StatusBadge from "@/components/StatusBadge";
import { toast } from "sonner";

export const Route = createFileRoute("/teacher/results")({
  head: () => ({ meta: [{ title: "Submit Results — Teacher Portal" }] }),
  component: TeacherResults,
});

function gradeFromTotal(total: number) {
  if (total >= 85) return "A";
  if (total >= 80) return "A-";
  if (total >= 75) return "B+";
  if (total >= 70) return "B";
  if (total >= 65) return "B-";
  if (total >= 60) return "C+";
  if (total >= 50) return "C";
  if (total >= 40) return "D";
  return "F";
}

type SubmitStatus = "Draft" | "Pending" | "Approved";

function TeacherResults() {
  const [course, setCourse] = useState(teacherCourseOptions[0].code);
  const [statusByCourse, setStatusByCourse] = useState<Record<string, SubmitStatus>>({
    CS301: "Draft", CS401: "Draft", CS601: "Approved",
  });

  const status = statusByCourse[course];
  const students = teacherStudents[course] ?? [];
  const data = gradebookSeed[course];

  const rows = useMemo(
    () =>
      students.map((s) => {
        const r = data[s.id];
        const total = r ? r.quiz + r.mid + r.assignment + r.final : 0;
        return { student: s, total, grade: gradeFromTotal(total) };
      }),
    [students, data],
  );

  const submit = () => {
    setStatusByCourse({ ...statusByCourse, [course]: "Pending" });
    toast.success(`Results for ${course} submitted to admin`, {
      description: "Status: Pending Approval",
    });
  };

  const locked = status !== "Draft";

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">Finalize Results</h1>
          <p className="mt-1 text-sm text-slate-400">Review and submit final grades to admin for approval.</p>
        </div>
        <button
          onClick={submit}
          disabled={locked}
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 px-4 py-2.5 text-sm font-bold text-slate-900 hover:from-amber-300 hover:to-amber-400 shadow-lg shadow-amber-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {locked ? <Lock className="h-4 w-4" /> : <Send className="h-4 w-4" />}
          {locked ? "Submitted" : "Submit to Admin"}
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Course</label>
          <select
            value={course}
            onChange={(e) => setCourse(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40"
          >
            {teacherCourseOptions.map((c) => (
              <option key={c.code} value={c.code} className="bg-slate-900">{c.label}</option>
            ))}
          </select>
        </div>
        <div className="flex items-end">
          <div className="rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2.5 w-full flex items-center justify-between">
            <p className="text-xs uppercase tracking-wider text-slate-400">Submission Status</p>
            <StatusBadge
              label={status === "Pending" ? "Pending Approval" : status}
              tone={status === "Approved" ? "success" : status === "Pending" ? "warning" : "neutral"}
            />
          </div>
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
        <table className="w-full text-sm">
          <thead className="bg-white/[0.03] text-left text-xs uppercase tracking-wider text-slate-400">
            <tr>
              <th className="px-6 py-3">Student</th>
              <th className="px-6 py-3">Reg #</th>
              <th className="px-6 py-3 text-right">Total Marks</th>
              <th className="px-6 py-3 text-right">Final Grade</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {rows.map((r) => (
              <tr key={r.student.id} className="hover:bg-white/[0.02]">
                <td className="px-6 py-3 font-medium text-white">{r.student.name}</td>
                <td className="px-6 py-3 font-mono text-xs text-slate-400">{r.student.reg}</td>
                <td className="px-6 py-3 text-right text-amber-400 tabular-nums">{r.total} / 110</td>
                <td className="px-6 py-3 text-right">
                  <span className={`inline-block rounded-md px-2 py-0.5 text-xs font-bold ${
                    r.grade === "F" ? "bg-rose-500/15 text-rose-300" :
                    r.grade.startsWith("A") ? "bg-emerald-500/15 text-emerald-300" :
                    "bg-amber-500/15 text-amber-300"
                  }`}>
                    {r.grade}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
