import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { TrendingUp, Calendar, Wallet, Clock, ArrowRight, BookOpen } from "lucide-react";
import { stats, notices, courses } from "@/data/data";
import StatusBadge from "@/components/StatusBadge";

export const Route = createFileRoute("/student/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Student Portal" }] }),
  component: Dashboard,
});

function useCountdown(target: string) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const diff = Math.max(0, new Date(target).getTime() - now);
  const days = Math.floor(diff / 86400000);
  const hrs = Math.floor((diff / 3600000) % 24);
  const mins = Math.floor((diff / 60000) % 60);
  const secs = Math.floor((diff / 1000) % 60);
  return { days, hrs, mins, secs };
}

function GlassCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-xl ${className}`}>
      <div className="absolute -top-10 -right-10 h-40 w-40 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />
      <div className="relative">{children}</div>
    </div>
  );
}

function Dashboard() {
  const c = useCountdown(stats.upcomingExam.date);
  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-amber-400">Welcome back</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight text-white">Good day, Ayesha 👋</h1>
        <p className="mt-1 text-sm text-slate-400">Here's a snapshot of your semester.</p>
      </div>

      {/* Stat row */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <GlassCard>
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium uppercase tracking-wider text-slate-400">Current GPA</p>
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-amber-500/15 text-amber-400">
              <TrendingUp className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-3 text-3xl font-bold text-white">{stats.gpa.toFixed(2)}</p>
          <p className="text-xs text-slate-500">CGPA {stats.cgpa.toFixed(2)}</p>
        </GlassCard>

        <GlassCard>
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium uppercase tracking-wider text-slate-400">Attendance</p>
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-500/15 text-emerald-400">
              <Calendar className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-3 text-3xl font-bold text-white">{stats.attendance}%</p>
          <div className="mt-2 h-1.5 w-full rounded-full bg-white/5">
            <div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-emerald-500" style={{ width: `${stats.attendance}%` }} />
          </div>
        </GlassCard>

        <GlassCard>
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium uppercase tracking-wider text-slate-400">Fee Status</p>
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-sky-500/15 text-sky-400">
              <Wallet className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-3 text-2xl font-bold text-white">All Cleared</p>
          <div className="mt-1"><StatusBadge label={stats.feeStatus} /></div>
        </GlassCard>

        <GlassCard>
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium uppercase tracking-wider text-slate-400">Next Exam</p>
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-rose-500/15 text-rose-400">
              <Clock className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-3 text-sm font-semibold text-white truncate">{stats.upcomingExam.subject}</p>
          <div className="mt-2 flex gap-2">
            {[
              { v: c.days, l: "d" },
              { v: c.hrs, l: "h" },
              { v: c.mins, l: "m" },
              { v: c.secs, l: "s" },
            ].map((x) => (
              <div key={x.l} className="rounded-md bg-white/5 px-2 py-1 text-center">
                <p className="text-sm font-bold text-amber-400 tabular-nums">{String(x.v).padStart(2, "0")}</p>
                <p className="text-[10px] text-slate-500 uppercase">{x.l}</p>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Courses preview */}
        <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-white/[0.02] p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-semibold text-white">Your Courses</h2>
            <Link to="/student/courses" className="flex items-center gap-1 text-xs text-amber-400 hover:underline">
              View all <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {courses.slice(0, 4).map((c) => (
              <div key={c.id} className="rounded-xl border border-white/5 bg-white/[0.03] p-4 hover:border-amber-500/30 transition">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <BookOpen className="h-3 w-3" /> {c.id}
                </div>
                <p className="mt-1 font-semibold text-white truncate">{c.name}</p>
                <p className="text-xs text-slate-400">{c.teacher}</p>
                <div className="mt-3 flex items-center gap-2">
                  <div className="h-1.5 flex-1 rounded-full bg-white/5">
                    <div className="h-full rounded-full bg-amber-500" style={{ width: `${c.progress}%` }} />
                  </div>
                  <span className="text-xs text-slate-400 tabular-nums">{c.progress}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Notices */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-semibold text-white">Recent Notices</h2>
            <Link to="/student/notices" className="text-xs text-amber-400 hover:underline">All</Link>
          </div>
          <ul className="space-y-3">
            {notices.slice(0, 4).map((n) => (
              <li key={n.id} className="border-l-2 border-amber-500/50 pl-3">
                <p className="text-sm font-medium text-white truncate">{n.title}</p>
                <p className="text-[11px] text-slate-500">{n.category} · {n.date}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
