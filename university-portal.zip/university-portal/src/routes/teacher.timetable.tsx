import { createFileRoute } from "@tanstack/react-router";
import { teacherTimetable } from "@/data/data";

export const Route = createFileRoute("/teacher/timetable")({
  head: () => ({ meta: [{ title: "Timetable — Teacher Portal" }] }),
  component: TeacherTimetable,
});

function TeacherTimetable() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">Teaching Schedule</h1>
        <p className="mt-1 text-sm text-slate-400">Cancelled classes are highlighted in red.</p>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-white/10 bg-white/[0.02]">
        <table className="w-full min-w-[900px] text-sm">
          <thead>
            <tr className="border-b border-white/10 bg-white/[0.03]">
              <th className="w-32 px-4 py-3 text-left text-xs uppercase tracking-wider text-slate-400">Time</th>
              {teacherTimetable.days.map((d) => (
                <th key={d} className="px-3 py-3 text-left text-xs uppercase tracking-wider text-slate-400">{d}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {teacherTimetable.slots.map((slot, slotIdx) => (
              <tr key={slot} className="border-b border-white/5">
                <td className="px-4 py-3 text-xs font-medium text-slate-500 tabular-nums">{slot}</td>
                {teacherTimetable.grid.map((day, dIdx) => {
                  const cell = day[slotIdx];
                  if (!cell) {
                    return <td key={dIdx} className="px-2 py-3"><div className="h-16 rounded-lg border border-dashed border-white/5" /></td>;
                  }
                  return (
                    <td key={dIdx} className="px-2 py-3">
                      <div
                        className={`h-16 rounded-lg border px-3 py-2 ${
                          cell.cancelled
                            ? "border-rose-500/30 bg-rose-500/10"
                            : "border-amber-500/20 bg-gradient-to-br from-amber-500/10 to-transparent hover:border-amber-500/40"
                        } transition`}
                      >
                        <p className={`text-xs font-semibold truncate ${cell.cancelled ? "text-rose-300 line-through" : "text-white"}`}>
                          {cell.course}
                        </p>
                        <p className="text-[10px] text-slate-400 truncate">{cell.section} · {cell.room}</p>
                        {cell.cancelled && <p className="text-[10px] font-bold text-rose-400 uppercase">Cancelled</p>}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
