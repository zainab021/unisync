import { createFileRoute, Link } from "@tanstack/react-router";
import { Users, ClipboardCheck, Calendar, ArrowRight, Plus, Megaphone, DoorOpen, PlaneTakeoff, CheckCircle2 } from "lucide-react";
import { teacherStats } from "@/data/data";
import StatusBadge from "@/components/StatusBadge";
import { toast } from "sonner";

export const Route = createFileRoute("/teacher/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Teacher Portal" }] }),
  component: TeacherDashboard,
});

const STATUS_TONE: Record<string, "success" | "warning" | "info"> = {
  Completed: "success",
  Ongoing: "warning",
  Upcoming: "info",
};

function TeacherDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-amber-400">Faculty</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight text-white">Welcome back, Dr. Imran 👋</h1>
        <p className="mt-1 text-sm text-slate-400">Here's what your day looks like.</p>
      </div>

      {/* Stat row */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Classes Today", value: teacherStats.classesToday.length, icon: Calendar, tone: "bg-amber-500/15 text-amber-400" },
          { label: "Total Students", value: teacherStats.totalStudents, icon: Users, tone: "bg-emerald-500/15 text-emerald-400" },
          { label: "Pending Tasks", value: teacherStats.pendingTasks.length, icon: ClipboardCheck, tone: "bg-rose-500/15 text-rose-400" },
          { label: "Avg Attendance", value: "91%", icon: CheckCircle2, tone: "bg-sky-500/15 text-sky-400" },
        ].map((s) => (
          <div key={s.label} className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-xl">
            <div className="absolute -top-10 -right-10 h-40 w-40 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />
            <div className="relative">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium uppercase tracking-wider text-slate-400">{s.label}</p>
                <div className={`grid h-9 w-9 place-items-center rounded-lg ${s.tone}`}>
                  <s.icon className="h-4 w-4" />
                </div>
              </div>
              <p className="mt-3 text-3xl font-bold text-white tabular-nums">{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-xl">
        <h2 className="mb-4 text-sm font-semibold text-white">Quick Actions</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: "Mark Attendance", to: "/teacher/attendance", icon: ClipboardCheck },
            { label: "Update Gradebook", to: "/teacher/gradebook", icon: Plus },
            { label: "Post a Notice", to: "/teacher/notices", icon: Megaphone },
            { label: "Request Room", to: "/teacher/room-request", icon: DoorOpen },
          ].map((a) => (
            <Link
              key={a.to}
              to={a.to}
              className="group flex items-center gap-3 rounded-xl border border-white/5 bg-white/[0.03] p-4 hover:border-amber-500/40 hover:bg-amber-500/5 transition"
            >
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-amber-500/15 text-amber-400 group-hover:bg-amber-500/25">
                <a.icon className="h-4 w-4" />
              </div>
              <span className="flex-1 text-sm font-medium text-slate-200 group-hover:text-white">{a.label}</span>
              <ArrowRight className="h-4 w-4 text-slate-500 group-hover:text-amber-400" />
            </Link>
          ))}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Today's classes */}
        <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
          <div className="flex items-center justify-between border-b border-white/5 px-6 py-4">
            <h2 className="text-base font-semibold text-white">Today's Classes</h2>
            <Link to="/teacher/timetable" className="flex items-center gap-1 text-xs text-amber-400 hover:underline">
              Full timetable <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
          <ul className="divide-y divide-white/5">
            {teacherStats.classesToday.map((c, i) => (
              <li key={i} className="flex items-center gap-4 px-6 py-4 hover:bg-white/[0.02]">
                <div className="grid place-items-center rounded-lg border border-amber-500/20 bg-amber-500/10 px-3 py-2 text-xs font-bold text-amber-300 tabular-nums">
                  {c.time.split(" - ")[0]}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-white truncate">{c.course}</p>
                  <p className="text-xs text-slate-400">{c.section} · {c.room}</p>
                </div>
                <StatusBadge label={c.status} tone={STATUS_TONE[c.status]} />
              </li>
            ))}
          </ul>
        </div>

        {/* Pending tasks */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
          <div className="flex items-center justify-between border-b border-white/5 px-6 py-4">
            <h2 className="text-base font-semibold text-white">Pending Tasks</h2>
            <PlaneTakeoff className="h-4 w-4 text-slate-500" />
          </div>
          <ul className="divide-y divide-white/5">
            {teacherStats.pendingTasks.map((t) => (
              <li key={t.id} className="flex items-start gap-3 px-5 py-3">
                <button
                  onClick={() => toast.success(`Marked complete: ${t.title}`)}
                  className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border border-white/15 hover:border-amber-400 hover:bg-amber-500/15"
                  aria-label="Complete task"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-slate-200">{t.title}</p>
                  <p className="text-[11px] text-slate-500">Due {t.due}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
