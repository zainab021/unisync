import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Save, Edit3 } from "lucide-react";
import { teacherCourseOptions, teacherStudents, gradebookSeed } from "@/data/data";
import { toast } from "sonner";

export const Route = createFileRoute("/teacher/gradebook")({
  head: () => ({ meta: [{ title: "Gradebook — Teacher Portal" }] }),
  component: Gradebook,
});

type Row = { quiz: number; mid: number; assignment: number; final: number };
const COLUMNS = [
  { key: "quiz", label: "Quiz", max: 20 },
  { key: "mid", label: "Mid-Term", max: 30 },
  { key: "assignment", label: "Assignment", max: 10 },
  { key: "final", label: "Final", max: 50 },
] as const;

function gradeFromTotal(total: number) {
  if (total >= 95) return "A+";
  if (total >= 85) return "A";
  if (total >= 80) return "A-";
  if (total >= 75) return "B+";
  if (total >= 70) return "B";
  if (total >= 65) return "B-";
  if (total >= 60) return "C+";
  if (total >= 50) return "C";
  if (total >= 40) return "D";
  return "F";
}

function Gradebook() {
  const [course, setCourse] = useState(teacherCourseOptions[0].code);
  const [data, setData] = useState<Record<string, Row>>(gradebookSeed[course]);

  useEffect(() => {
    setData(gradebookSeed[course]);
  }, [course]);

  const students = teacherStudents[course] ?? [];

  const update = (sid: string, key: keyof Row, value: number) => {
    setData((d) => ({ ...d, [sid]: { ...d[sid], [key]: value } }));
  };

  const classAvg = useMemo(() => {
    const totals = students.map((s) => {
      const r = data[s.id];
      return r ? r.quiz + r.mid + r.assignment + r.final : 0;
    });
    if (!totals.length) return 0;
    return totals.reduce((a, b) => a + b, 0) / totals.length;
  }, [data, students]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white flex items-center gap-2">
            <Edit3 className="h-6 w-6 text-amber-400" /> Gradebook
          </h1>
          <p className="mt-1 text-sm text-slate-400">Click any cell to edit. Totals and grades update live.</p>
        </div>
        <button
          onClick={() => toast.success(`Gradebook saved for ${course}`)}
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 px-4 py-2.5 text-sm font-bold text-slate-900 hover:from-amber-300 hover:to-amber-400 shadow-lg shadow-amber-500/20"
        >
          <Save className="h-4 w-4" /> Save Gradebook
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <div>
          <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Course</label>
          <select
            value={course}
            onChange={(e) => setCourse(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40"
          >
            {teacherCourseOptions.map((c) => (
              <option key={c.code} value={c.code} className="bg-slate-900">{c.label}</option>
            ))}
          </select>
        </div>
        <div className="rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3">
          <p className="text-xs text-slate-500">Class Average</p>
          <p className="text-lg font-bold text-amber-400 tabular-nums">{classAvg.toFixed(1)} / 110</p>
        </div>
        <div className="rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3">
          <p className="text-xs text-slate-500">Students</p>
          <p className="text-lg font-bold text-white tabular-nums">{students.length}</p>
        </div>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-white/10 bg-white/[0.02]">
        <table className="w-full min-w-[800px] text-sm">
          <thead className="bg-white/[0.03] text-left text-xs uppercase tracking-wider text-slate-400">
            <tr>
              <th className="px-6 py-3">Student</th>
              {COLUMNS.map((c) => (
                <th key={c.key} className="px-4 py-3 text-center">
                  {c.label}
                  <span className="ml-1 text-slate-600">/{c.max}</span>
                </th>
              ))}
              <th className="px-4 py-3 text-center">Total</th>
              <th className="px-4 py-3 text-center">Grade</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {students.map((s) => {
              const r = data[s.id];
              if (!r) return null;
              const total = r.quiz + r.mid + r.assignment + r.final;
              const grade = gradeFromTotal(total);
              return (
                <tr key={s.id} className="hover:bg-white/[0.02]">
                  <td className="px-6 py-2.5">
                    <p className="font-medium text-white">{s.name}</p>
                    <p className="text-[11px] font-mono text-slate-500">{s.reg}</p>
                  </td>
                  {COLUMNS.map((c) => (
                    <td key={c.key} className="px-4 py-2.5 text-center">
                      <input
                        type="number"
                        min={0}
                        max={c.max}
                        value={r[c.key]}
                        onChange={(e) => update(s.id, c.key, Math.min(c.max, Math.max(0, Number(e.target.value) || 0)))}
                        className="w-16 rounded-md border border-white/10 bg-white/5 px-2 py-1.5 text-center text-sm text-white outline-none tabular-nums focus:border-amber-500/60 focus:bg-amber-500/5"
                      />
                    </td>
                  ))}
                  <td className="px-4 py-2.5 text-center font-bold text-amber-400 tabular-nums">{total}</td>
                  <td className="px-4 py-2.5 text-center">
                    <span className={`rounded-md px-2 py-0.5 text-xs font-bold ${
                      grade === "F" ? "bg-rose-500/15 text-rose-300" :
                      grade.startsWith("A") ? "bg-emerald-500/15 text-emerald-300" :
                      "bg-amber-500/15 text-amber-300"
                    }`}>
                      {grade}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
