import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PlaneTakeoff } from "lucide-react";
import { leaveHistory, leaveTypes } from "@/data/data";
import StatusBadge from "@/components/StatusBadge";
import { toast } from "sonner";

export const Route = createFileRoute("/teacher/leave")({
  head: () => ({ meta: [{ title: "Leave Application — Teacher Portal" }] }),
  component: LeavePage,
});

type Application = {
  id: string;
  type: string;
  from: string;
  to: string;
  days: number;
  reason: string;
  status: "Pending" | "Approved" | "Rejected";
};

function LeavePage() {
  const [type, setType] = useState(leaveTypes[0]);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [reason, setReason] = useState("");
  const [history, setHistory] = useState<Application[]>(leaveHistory);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!from || !to || !reason.trim()) return toast.error("Please fill in all fields");
    if (new Date(from) > new Date(to)) return toast.error("End date must be after start date");
    const days = Math.max(1, Math.round((new Date(to).getTime() - new Date(from).getTime()) / 86400000) + 1);
    const id = `LV-${new Date().getFullYear()}-${String(history.length + 25).padStart(3, "0")}`;
    setHistory([{ id, type, from, to, days, reason, status: "Pending" }, ...history]);
    toast.success("Leave application submitted", { description: `${days} day(s) · awaiting approval` });
    setFrom(""); setTo(""); setReason("");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white flex items-center gap-2">
          <PlaneTakeoff className="h-6 w-6 text-amber-400" /> Leave Application
        </h1>
        <p className="mt-1 text-sm text-slate-400">Apply for leave and track your past applications.</p>
      </div>

      <form onSubmit={submit} className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-xl space-y-4">
        <h2 className="text-base font-semibold text-white">New Application</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Leave Type</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40"
            >
              {leaveTypes.map((t) => <option key={t} className="bg-slate-900">{t}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">From</label>
              <input
                type="date"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40 [color-scheme:dark]"
              />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">To</label>
              <input
                type="date"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40 [color-scheme:dark]"
              />
            </div>
          </div>
        </div>
        <div>
          <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Reason</label>
          <textarea
            rows={3}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Briefly describe the reason for leave..."
            className="mt-1.5 w-full resize-none rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40 placeholder:text-slate-600"
          />
        </div>
        <button
          type="submit"
          className="rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 px-5 py-2.5 text-sm font-bold text-slate-900 hover:from-amber-300 hover:to-amber-400 shadow-lg shadow-amber-500/20"
        >
          Submit Application
        </button>
      </form>

      <div className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
        <div className="border-b border-white/5 px-6 py-4">
          <h2 className="font-semibold text-white">Past Applications</h2>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-white/[0.02] text-left text-xs uppercase tracking-wider text-slate-400">
            <tr>
              <th className="px-6 py-3">ID</th>
              <th className="px-6 py-3">Type</th>
              <th className="px-6 py-3">Dates</th>
              <th className="px-6 py-3">Days</th>
              <th className="px-6 py-3">Reason</th>
              <th className="px-6 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {history.map((a) => (
              <tr key={a.id} className="hover:bg-white/[0.02]">
                <td className="px-6 py-3 font-mono text-xs text-slate-400">{a.id}</td>
                <td className="px-6 py-3 text-white">{a.type}</td>
                <td className="px-6 py-3 text-slate-300 tabular-nums">{a.from} → {a.to}</td>
                <td className="px-6 py-3 text-amber-400 tabular-nums">{a.days}</td>
                <td className="px-6 py-3 text-slate-400 max-w-xs truncate">{a.reason}</td>
                <td className="px-6 py-3">
                  <StatusBadge
                    label={a.status}
                    tone={a.status === "Approved" ? "success" : a.status === "Rejected" ? "danger" : "warning"}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
