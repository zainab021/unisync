import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Megaphone, Plus } from "lucide-react";
import { notices as initial, noticeCategories } from "@/data/data";
import Modal from "@/components/Modal";
import { toast } from "sonner";

export const Route = createFileRoute("/teacher/notices")({
  head: () => ({ meta: [{ title: "Notices — Teacher Portal" }] }),
  component: TeacherNotices,
});

const CATEGORY_COLOR: Record<string, string> = {
  Academic: "border-amber-500/30 bg-amber-500/15 text-amber-300",
  Library: "border-sky-500/30 bg-sky-500/15 text-sky-300",
  Event: "border-violet-500/30 bg-violet-500/15 text-violet-300",
  Finance: "border-emerald-500/30 bg-emerald-500/15 text-emerald-300",
  General: "border-slate-500/30 bg-slate-500/15 text-slate-300",
};

const POSTABLE = noticeCategories.filter((c) => c !== "All");

function TeacherNotices() {
  const [tab, setTab] = useState<"view" | "post">("view");
  const [items, setItems] = useState(initial);
  const [open, setOpen] = useState(false);

  // form
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Academic");
  const [body, setBody] = useState("");

  const post = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return toast.error("Please fill in all fields");
    setItems([
      { id: Date.now(), title, category, body, date: new Date().toISOString().slice(0, 10) },
      ...items,
    ]);
    toast.success("Notice posted to all students");
    setTitle(""); setBody(""); setCategory("Academic");
    setOpen(false);
    setTab("view");
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">Notices</h1>
          <p className="mt-1 text-sm text-slate-400">View university notices or post your own.</p>
        </div>
        <button
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 px-4 py-2.5 text-sm font-bold text-slate-900 hover:from-amber-300 hover:to-amber-400 shadow-lg shadow-amber-500/20"
        >
          <Plus className="h-4 w-4" /> Post Notice
        </button>
      </div>

      <div className="inline-flex rounded-lg border border-white/10 bg-white/5 p-1">
        {[
          { id: "view", label: "View All Notices" },
          { id: "post", label: "Post Notice" },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => t.id === "post" ? setOpen(true) : setTab("view")}
            className={`rounded-md px-4 py-1.5 text-sm font-medium transition ${
              tab === t.id ? "bg-amber-500 text-slate-900" : "text-slate-400 hover:text-white"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {items.map((n) => (
          <div key={n.id} className="flex gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur-xl">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-amber-500/15 text-amber-400">
              <Megaphone className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase ${CATEGORY_COLOR[n.category] ?? CATEGORY_COLOR.General}`}>
                  {n.category}
                </span>
                <span className="text-xs text-slate-500 tabular-nums">{n.date}</span>
              </div>
              <h3 className="mt-2 font-semibold text-white">{n.title}</h3>
              <p className="mt-1 text-sm text-slate-400">{n.body}</p>
            </div>
          </div>
        ))}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Post a New Notice">
        <form onSubmit={post} className="space-y-4">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Title</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40"
              placeholder="e.g. Quiz 3 rescheduled to Friday"
            />
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40"
            >
              {POSTABLE.map((c) => <option key={c} className="bg-slate-900">{c}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-400">Message</label>
            <textarea
              rows={4}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Write the notice details..."
              className="mt-1.5 w-full resize-none rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-amber-500/40 placeholder:text-slate-600"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="rounded-lg border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-300 hover:bg-white/10"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-amber-500 px-4 py-2 text-sm font-bold text-slate-900 hover:bg-amber-400"
            >
              Post Notice
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
